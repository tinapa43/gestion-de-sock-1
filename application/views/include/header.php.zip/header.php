
<!DOCTYPE html>
<html>
<head>
	<title>Gestion Stocks</title>

    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/modern-business.css') ?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <script type="text/javascript" src="<?= base_url('assets/js/jquery.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('assets/js/jquery-1.10.2.min.js') ?>"></script>
    
</head>
<body>
  <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
            <a class="navbar-brand" href="<?= base_url()?>">Gestion Stocks</a>
      </div>
      <div id="navbar" class="navbar-collapse collapse">
      	<div class="navbar-form navbar-right">
  		<a href="<?php echo base_url() ?>index.php/dashboard/logout" type="submit" class="btn btn-success"><i class="fa fa-sign-out"></i> Logout</a>
      	</div>
    </div>
  </nav>
  <div class="container" style="margin-top: 20px">
  	<div class="row">
  		<div class="col-md-3">
  			<div class="side-menu">
      		<nav class="navbar navbar-default" role="navigation">
      			<div class="side-menu-container">
      				<ul class="nav navbar-nav">
      					<li class="active"><a href="<?= base_url()?>"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a></li>
      					<li class="panel panel-default" id="dropdown">
      						<a data-toggle="collapse" href="#dropdown-lvl1"> <span class="glyphicon glyphicon-user"></span> Achats <span class="caret"></span> </a>
      						<div id="dropdown-lvl1" class="panel-collapse collapse">
      							<div class="panel-body">
      								<ul class="nav navbar-nav">
      									<li><a href="<?= base_url('Achats/add_achat') ?>"> Achat Articles </a></li>
                                        <li><a href="<?= base_url('Achats/list_achats') ?>"> List Achats </a></li>
                                        <li><a href="<?= base_url('Achats/list_reglement') ?>"> List Reglement </a></li>
      								</ul>
      							</div>
      						</div>
      					</li>
              					
                        <li class="panel panel-default" id="dropdown">
                          <a data-toggle="collapse" href="#dropdown-lvl3"> <span class="glyphicon glyphicon-user"></span> Ventes <span class="caret"></span> </a>
                          <div id="dropdown-lvl3" class="panel-collapse collapse">
                            <div class="panel-body">
                              <ul class="nav navbar-nav">
                                <li><a href="<?= base_url('index.php/Stocks/Add') ?>"> Ventes </a></li>
                                <li><a href="<?= base_url('index.php/Stocks/view') ?>"> List Ventes </a></li>
                                <li><a href="<?= base_url('index.php/Stocks/view') ?>"> List Reglement </a></li>
                              </ul>
                            </div>
                          </div>
                        </li>
                        <li class="panel panel-default" id="dropdown">
                          <a data-toggle="collapse" href="#dropdown-lvl0"> <span class="glyphicon glyphicon-user"></span> Stocks <span class="caret"></span> </a>
                          <div id="dropdown-lvl0" class="panel-collapse collapse">
                            <div class="panel-body">
                              <ul class="nav navbar-nav">
                                <li><a href="<?= base_url('index.php/Stocks/list_stock') ?>"> Voire Stocks </a></li>
                                <li><a href="<?= base_url('index.php/Stocks/list_depot') ?>"> Voire Depots </a></li>
                                <li><a href="<?= base_url('index.php/Stocks/rep_stock') ?>"> Repture Stocks </a></li>
                                <li><a href="<?= base_url('index.php/Stocks/add_article') ?>"> Nouveau Articles </a></li>
                                <li><a href="<?= base_url('index.php/Stocks/list_article') ?>"> Tous les Articles </a></li>
                              </ul>
                            </div>
                          </div>
                        </li>
                        <li class="panel panel-default" id="dropdown">
                          <a data-toggle="collapse" href="#dropdown-lvl2"> <span class="glyphicon glyphicon-user"></span> Configure <span class="caret"></span> </a>
                          <div id="dropdown-lvl2" class="panel-collapse collapse">
                            <div class="panel-body">
                              <ul class="nav navbar-nav">
                                <li><a href="<?= base_url('index.php/frs/add') ?>"> Fournisseur </a></li>
                                <li><a href="<?= base_url('index.php/clt/add') ?>"> Clients </a></li>
                                <li><a href="<?= base_url('index.php/config/view') ?>"> Affichier </a></li>
                              </ul>
                            </div>
                          </div>
                        </li>
      					<li><a href="<?= base_url('index.php/login/logout') ?>"><span class="glyphicon glyphicon-signal"></span> Logout </a></li>
      				</ul>
      			</div>
      		</nav>
        </div>
  		</div>
  		<script>
  		    $(function () {
                	$('.navbar-toggle-sidebar').click(function () {
                		$('.navbar-nav').toggleClass('slide-in');
                		$('.side-body').toggleClass('body-slide-in');
                		$('#search').removeClass('in').addClass('collapse').slideUp(200);
                	});
                      
                	$('#search-trigger').click(function () {
                		$('.navbar-nav').removeClass('slide-in');
                		$('.side-body').removeClass('body-slide-in');
                		$('.search-input').focus();
                	});
                });
  		</script>